namespace First_Project_C__3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void FirstNumberInput_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void SecondNumberInput_TextChanged(object sender, EventArgs e)
        {

        }

        private void ResultOutput_TextChanged(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            double FirstNumber = Convert.ToDouble(FirstNumberInput.Text);
            double SecondNumber = Convert.ToDouble(SecondNumberInput.Text);
            float Result = (float)(FirstNumber + SecondNumber);
            ResultOutput.Text = " " + Result.ToString();
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            double FirstNumber = Convert.ToDouble(FirstNumberInput.Text);
            int SecondNumber = Convert.ToInt32(SecondNumberInput.Text);
            float Result = (float)(FirstNumber - SecondNumber);
            ResultOutput.Text = " " + Result.ToString();
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            double FirstNumber = Convert.ToDouble(FirstNumberInput.Text);
            int SecondNumber = Convert.ToInt32(SecondNumberInput.Text);
            float Result = (float)(FirstNumber * SecondNumber);
            ResultOutput.Text = " " + Result.ToString();
        }

        private void Button4_Click(object sender, EventArgs e)
        {
            double FirstNumber = Convert.ToDouble(FirstNumberInput.Text);
            int SecondNumber = Convert.ToInt32(SecondNumberInput.Text);
            if (SecondNumber != 0)
            {
                float Result = (float)(FirstNumber / SecondNumber);
                ResultOutput.Text = " " + Result.ToString();
            }
            else
            {
                ResultOutput.Text = "Cannot divide by zero!";
            }
        }
    }
}