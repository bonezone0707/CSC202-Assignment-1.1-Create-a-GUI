﻿namespace First_Project_C__3
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            FirstNumber = new Label();
            SecondNumber = new Label();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            Result = new Label();
            FirstNumberInput = new TextBox();
            SecondNumberInput = new TextBox();
            ResultOutput = new TextBox();
            SuspendLayout();
            // 
            // FirstNumber
            // 
            FirstNumber.AutoSize = true;
            FirstNumber.Location = new Point(148, 88);
            FirstNumber.Name = "FirstNumber";
            FirstNumber.Size = new Size(97, 20);
            FirstNumber.TabIndex = 0;
            FirstNumber.Text = "First Number:";
            // 
            // SecondNumber
            // 
            SecondNumber.AutoSize = true;
            SecondNumber.Location = new Point(148, 156);
            SecondNumber.Name = "SecondNumber";
            SecondNumber.Size = new Size(119, 20);
            SecondNumber.TabIndex = 1;
            SecondNumber.Text = "Second Number:";
            // 
            // button1
            // 
            button1.Location = new Point(148, 212);
            button1.Name = "button1";
            button1.Size = new Size(94, 29);
            button1.TabIndex = 2;
            button1.Text = "+";
            button1.UseVisualStyleBackColor = true;
            button1.Click += Button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(248, 212);
            button2.Name = "button2";
            button2.Size = new Size(94, 29);
            button2.TabIndex = 3;
            button2.Text = "-";
            button2.UseVisualStyleBackColor = true;
            button2.Click += Button2_Click;
            // 
            // button3
            // 
            button3.Location = new Point(357, 212);
            button3.Name = "button3";
            button3.Size = new Size(94, 29);
            button3.TabIndex = 4;
            button3.Text = "*";
            button3.UseVisualStyleBackColor = true;
            button3.Click += Button3_Click;
            // 
            // button4
            // 
            button4.Location = new Point(466, 212);
            button4.Name = "button4";
            button4.Size = new Size(94, 29);
            button4.TabIndex = 5;
            button4.Text = "/";
            button4.UseVisualStyleBackColor = true;
            button4.Click += Button4_Click;
            // 
            // Result
            // 
            Result.AutoSize = true;
            Result.Location = new Point(148, 316);
            Result.Name = "Result";
            Result.Size = new Size(52, 20);
            Result.TabIndex = 6;
            Result.Text = "Result:";
            // 
            // FirstNumberInput
            // 
            FirstNumberInput.Location = new Point(263, 88);
            FirstNumberInput.Name = "FirstNumberInput";
            FirstNumberInput.Size = new Size(125, 27);
            FirstNumberInput.TabIndex = 7;
            FirstNumberInput.TextChanged += FirstNumberInput_TextChanged;
            // 
            // SecondNumberInput
            // 
            SecondNumberInput.Location = new Point(273, 156);
            SecondNumberInput.Name = "SecondNumberInput";
            SecondNumberInput.Size = new Size(125, 27);
            SecondNumberInput.TabIndex = 8;
            SecondNumberInput.TextChanged += SecondNumberInput_TextChanged;
            // 
            // ResultOutput
            // 
            ResultOutput.Location = new Point(206, 313);
            ResultOutput.Name = "ResultOutput";
            ResultOutput.Size = new Size(125, 27);
            ResultOutput.TabIndex = 9;
            ResultOutput.TextChanged += ResultOutput_TextChanged;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.Highlight;
            ClientSize = new Size(845, 490);
            Controls.Add(ResultOutput);
            Controls.Add(SecondNumberInput);
            Controls.Add(FirstNumberInput);
            Controls.Add(Result);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(SecondNumber);
            Controls.Add(FirstNumber);
            Name = "Form1";
            Text = "Simple Calculator";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label FirstNumber;
        private Label SecondNumber;
        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Label Result;
        private TextBox FirstNumberInput;
        private TextBox SecondNumberInput;
        private TextBox ResultOutput;
    }
}
